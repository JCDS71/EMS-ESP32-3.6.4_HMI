export const PROJECT_NAME = 'EMS-ESP';
