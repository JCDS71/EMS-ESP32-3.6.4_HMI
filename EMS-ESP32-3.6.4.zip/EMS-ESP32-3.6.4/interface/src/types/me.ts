export interface Me {
  username: string;
  admin: boolean;
}
