export interface Features {
  version: string;
  platform: string; // "ESP32-C3" "ESP32-S2" "ESP32-S3" "ESP32"
}
