export { default as SingleUpload } from './SingleUpload';
