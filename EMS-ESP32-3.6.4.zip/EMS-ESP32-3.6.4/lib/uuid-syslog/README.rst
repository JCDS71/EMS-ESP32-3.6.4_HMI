mcu-uuid-syslog |Build Status|
==============================

Description
-----------

Microcontroller syslog service

Purpose
-------

Provides a log handler that sends messages to a syslog server (using
the `RFC 5424 protocol <https://tools.ietf.org/html/rfc5424>`_).

Documentation
-------------

`Read the documentation <https://mcu-uuid-syslog.readthedocs.io/>`_
generated from the docs_ directory.

.. _docs: docs/

.. |Build Status| image:: https://travis-ci.org/nomis/mcu-uuid-syslog.svg?branch=master
   :target: https://travis-ci.org/nomis/mcu-uuid-syslog
