mcu-uuid-telnet |Build Status|
==============================

Description
-----------

Microcontroller telnet service

Purpose
-------

Provides access to a console shell as a telnet server (using the
`RFC 854 protocol <https://tools.ietf.org/html/rfc854>`_).

Documentation
-------------

`Read the documentation <https://mcu-uuid-telnet.readthedocs.io/>`_
generated from the docs_ directory.

.. _docs: docs/

.. |Build Status| image:: https://travis-ci.org/nomis/mcu-uuid-telnet.svg?branch=master
   :target: https://travis-ci.org/nomis/mcu-uuid-telnet
