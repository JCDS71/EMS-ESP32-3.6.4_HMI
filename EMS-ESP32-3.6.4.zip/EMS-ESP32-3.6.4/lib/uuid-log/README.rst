mcu-uuid-log |Build Status|
===========================

Description
-----------

Microcontroller logging framework

Purpose
-------

Provides a framework for handling log messages. This library is for
single threaded applications and cannot be used from an interrupt
context.

Documentation
-------------

`Read the documentation <https://mcu-uuid-log.readthedocs.io/>`_ generated
from the docs_ directory.

.. _docs: docs/

.. |Build Status| image:: https://travis-ci.org/nomis/mcu-uuid-log.svg?branch=master
   :target: https://travis-ci.org/nomis/mcu-uuid-log
