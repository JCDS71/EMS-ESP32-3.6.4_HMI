mcu-uuid-console |Build Status|
===============================

Description
-----------

Microcontroller console shell

Purpose
-------

Provides a framework for creating a console shell with commands. The
container of commands (``uuid::console::Commands``) can be shared
across multiple shell instances.

Documentation
-------------

`Read the documentation <https://mcu-uuid-console.readthedocs.io/>`_ generated
from the docs_ directory.

.. _docs: docs/

.. |Build Status| image:: https://travis-ci.org/nomis/mcu-uuid-console.svg?branch=master
   :target: https://travis-ci.org/nomis/mcu-uuid-console
