#include <StatefulService.h>

update_handler_id_t StateUpdateHandlerInfo::currentUpdatedHandlerId = 0;
